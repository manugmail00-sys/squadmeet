// Textos del menú de la extensión en el idioma del navegador (_locales).
for (const el of document.querySelectorAll('[data-t]')) el.textContent = chrome.i18n.getMessage(el.dataset.t);
document.documentElement.lang = chrome.i18n.getUILanguage().startsWith('es') ? 'es' : 'en';
