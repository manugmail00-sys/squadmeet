// SquadMeet — puente entre la página (ome.tv o squadmeet.app) y el almacén de la extensión.
// Así el navegador es el mismo «dispositivo» en las dos webs: si pagas Pro en squadmeet.app, el panel
// de ome.tv ya es Pro, sin hacer nada más. Corre en el mundo aislado (tiene chrome.storage) y habla
// con la página por postMessage. Guarda el identificador al azar del navegador y el correo de la cuenta
// de SquadMeet (vacío: ha salido de la cuenta). Así entrar, salir o pagar en una web vale en la otra.
(() => {
  const almacen = chrome.storage.local;
  const VALIDO = /^[a-z0-9]{16,40}$/;
  const CLAVE_DISPOSITIVO = 'squadmeet:dispositivo', CLAVE_CORREO = 'squadmeet:correo';
  const aleatorio = () => [...crypto.getRandomValues(new Uint8Array(24))].map((b) => 'abcdefghijklmnopqrstuvwxyz0123456789'[b % 36]).join('');
  const local = (k) => { try { return localStorage.getItem(k) || ''; } catch { return ''; } };
  const guardarLocal = (k, v) => { try { if (v) localStorage.setItem(k, v); else localStorage.removeItem(k); } catch {} };

  // Lo que manda el almacén; si aún no hay nada, se adopta lo que ya tuviera esta web (el panel de
  // versiones anteriores, o una compra hecha en la web antes de instalar la extensión).
  async function leer() {
    const g = await almacen.get(['dispositivo', 'correo']);
    let dispositivo = VALIDO.test(g.dispositivo || '') ? g.dispositivo : '';
    // Correo vacío es «ha salido»; sin correo guardado nunca, se adopta el de la página.
    let correo = typeof g.correo === 'string' ? g.correo : '';
    const cambios = {};
    if (!dispositivo) {
      dispositivo = VALIDO.test(local(CLAVE_DISPOSITIVO)) ? local(CLAVE_DISPOSITIVO) : aleatorio();
      cambios.dispositivo = dispositivo;
    }
    if (g.correo === undefined && local(CLAVE_CORREO)) correo = cambios.correo = local(CLAVE_CORREO);
    if (Object.keys(cambios).length) await almacen.set(cambios);
    guardarLocal(CLAVE_DISPOSITIVO, dispositivo);
    guardarLocal(CLAVE_CORREO, correo);
    return { dispositivo, correo };
  }
  const contar = async (motivo) => window.postMessage({ tipo: 'squadmeet:puente', motivo, ...(await leer()) }, location.origin);

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || typeof e.data !== 'object') return;
    if (e.data.tipo === 'squadmeet:puente?') contar('pregunta');
    else if (e.data.tipo === 'squadmeet:correo' && typeof e.data.correo === 'string' && e.data.correo.length < 260) almacen.set({ correo: e.data.correo.trim() });
    // La web ha visto que ya es Pro: se avisa a las demás pestañas (el panel de ome.tv lo comprueba).
    else if (e.data.tipo === 'squadmeet:pro') almacen.set({ pro: Date.now() });
  });
  // Si otra pestaña cambia algo (el correo o una compra), esta página se entera al momento.
  chrome.storage.onChanged.addListener((cambios, zona) => { if (zona === 'local') contar('cambio'); });
  contar('inicio');
})();
