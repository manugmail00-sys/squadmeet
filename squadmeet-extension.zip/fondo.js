// SquadMeet — al instalar la extensión se abre la web: da la bienvenida y, como el puente corre allí
// primero, si ya se había pagado Pro en la web antes de instalarla, ese Pro pasa a la extensión.
chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason !== 'install') return;
  const sitio = chrome.runtime.getManifest().homepage_url || 'https://squadmeet.app/';
  chrome.tabs.create({ url: `${sitio}${chrome.i18n.getUILanguage().startsWith('es') ? '' : 'en/'}?instalada=1` });
});
